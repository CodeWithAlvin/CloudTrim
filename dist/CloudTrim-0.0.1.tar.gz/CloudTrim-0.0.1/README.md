
# CloudTrimmer
Trim On cloud
### A library for trimming video and downpoading them



  
![Logo](https://raw.githubusercontent.com/CodeWithAlvin/CloudTrimmer-web/master/static/images/logo.svg)

    
## Authors

- [@alvinsaini](https://www.github.com/codewithalvin)

  
## Documentation


  
## Contributing

Contributions are always welcome!

  
## License

[MIT](https://github.com/CodeWithAlvin/CloudTrimmer/blob/master/license)

  
